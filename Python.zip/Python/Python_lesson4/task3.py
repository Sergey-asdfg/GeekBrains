# Lesson 4, Task 3

print([el for el in range(20,(240+1)) if el%20 == 0 or el%21 == 0])
