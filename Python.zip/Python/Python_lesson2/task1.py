# Lesson2, Task 1
for i in range (0,4):
    my_list[i] = input('Enter integer: ')

for i in my_list:
    print(type(i))
