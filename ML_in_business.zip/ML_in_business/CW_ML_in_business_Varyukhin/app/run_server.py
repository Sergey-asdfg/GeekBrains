# импортируем необходимые библиотеки
import pandas as pd
import numpy as np
import string
import dill
from sklearn.base import BaseEstimator
import nltk
from nltk.stem import WordNetLemmatizer, SnowballStemmer
nltk.download('wordnet')
nltk.download('punkt')
stemmer = SnowballStemmer('russian')
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import MinMaxScaler
from sklearn.pipeline import Pipeline
from urllib import request, parse
import urllib.request
import json

# загружаем пайпланы с моделями определения токсичных (невежливых/нецензурных) высказываний-вопросов к чатботу,
# а также пайплайн модели болталки чат-бота
with open('toxic_pipeline.dill', 'rb') as f:
    toxic_pipeline = dill.load(f)
with open('chat_pipeline.dill', 'rb') as f:
    chat_pipeline = dill.load(f)

def softmax(x):
    """Функция для создания вероятностного распределения"""
    proba = np.exp(-x)
    return proba / sum(proba)

class NeighborSampler(BaseEstimator):
    """Класс для случайного выбора одного из соседей для ответа чат-бота"""
    def __init__(self, k=5, temperature=1.0):
        self.k = k
        self.temperature = temperature
    def fit(self, X, y):
        self.tree_ = BallTree(X)
        self.y_ = np.array(y)
    def predict(self, X, randome_state=None):
        distances, indices = self.tree_.query(X, return_distance=True, k=self.k)
        result = []
        for distance, index in zip(distances, indices):
            result.append(np.random.choice(index, p=softmax(distance * self.temperature)))
        return self.y_[result]

# функция получения ответа (prediction) от чат-бота, на первом шаге - оценка токсичности вопроса или фразы,
# на втором - сам ответ
def prediction(question):
    comment = []
    phrase = question
    # Punctuation removal
    table = str.maketrans(dict.fromkeys(string.punctuation))                   
    sentence = (phrase.translate(table))

    # Tokenization
    words = nltk.word_tokenize(sentence)

    # shrt words removal & lemmatization & stemming
    words_ = []
    for word in words:
        if len(word) > 2:   
            if not word.isnumeric():                                                  
                word1 = stemmer.stem(WordNetLemmatizer().lemmatize(word, pos='v'))          
                words_.append(word1)
    comment.append(words_)

    # необходимые преобразования текста перед запуском пайплайнов
    ds_comment = pd.Series(comment)
    frase = ds_comment.astype(str).values.tolist()
    
    # предсказывание наличия токсичности и фильтация на её основе
    if toxic_pipeline.predict(frase)[0] > 0:
        warning = "Вы говорите невежливо, пожалуйста, смените тон пожалуйста."
        return warning
    else:
        return chat_pipeline.predict(frase)[0] # предсказывание ответа Chat-bot на основе выбора ближ соседей ответа после PCA(300 comp.)

# импортируем всё необходимое для Flask
from flask import Flask, make_response, render_template, request

# создаём экземпляр класса
app = Flask(__name__)

# задаём функцию login() для работы из корня сайта, декорируем методами POST and GET для отсылки и приёма ответа от чат-бота
@app.route('/', methods=['post', 'get'])
def login():
    answer = ''
    question = ''
    if request.method == 'POST':
        question = request.form.get('question') # запрос к чат-боту

    answer = prediction(question) # ответ от чатбота чат-боту

    return render_template('login.html', message='Чат-бот: ' + answer) # возвращение ответа чат-бота в браузер

if __name__ == "__main__":
    app.run(debug=True) # запуск экземпляра Фласка в режиме дебагинга
